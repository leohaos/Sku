Run tests

pytest test_prompts.py
